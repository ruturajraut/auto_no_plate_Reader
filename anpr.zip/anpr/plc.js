var ads = require('ads-client');
const gvl = require('./gvl');

const client = new ads.Client({
    targetAmsNetId: gvl.controller_net_id,
    targetAdsPort: gvl.controller_port,
})

async function connectClient(){

    if(client.connection.connected){
        return true;
    }

    connectionStatus = await client.connect();
    console.dir(connectionStatus,{depth:2});
    return connectionStatus.connected;

    // client.connect()
    //     .then(res => {   
    //         console.log(`Connected to the ${res.targetAmsNetId}`)
    //         console.log(`Router assigned us AmsNetId ${res.localAmsNetId} and port ${res.localAdsPort}`)
    //     })
    //     .catch(err => {
    //         console.log('Something failed:', err)
    //     })

}



async function openFourWheelerEntryBoom(){
    
    let connectionStatus = await connectClient();
    // console.log(connectionStatus);

    
    try {
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
        const res = await client.writeSymbol('GVL.fourWheelerEntryGateCommand', true)
        console.log('GVL.fourWheelerEntryGateCommand , Value written:', res.value);
        setTimeout(async function(){
            return await closeFourWheelerEntryBoom();
        },2000);
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
    
}

async function closeFourWheelerEntryBoom(){

    let connectionStatus = await connectClient();
    // console.log(connectionStatus);

    try {
        const res = await client.writeSymbol('GVL.fourWheelerEntryGateCommand', false)
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false)
        console.log('GVL.fourWheelerEntryGateCommand , Value written:', res.value);
        return true;
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
}


async function openFourWheelerExitBoom(){
    
    let connectionStatus = await connectClient();
    console.log(connectionStatus);

    
    try {
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', true)
        const res = await client.writeSymbol('GVL.fourWheelerExitGateCommand', true)
        console.log('GVL.fourWheelerExitGateCommand, Value written:', res.value);
        setTimeout(async function(){
            return await closeFourWheelerExitBoom();
        },2000);
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
    
}

async function closeFourWheelerExitBoom(){

    let connectionStatus = await connectClient();
    console.log(connectionStatus);

    try {
        const res = await client.writeSymbol('GVL.fourWheelerExitGateCommand', false)
        const vtran = await client.writeSymbol('GVL.is_vehicle_transaction_on', false)
        console.log('GVL.fourWheelerExitGateCommand , Value written:', res.value);
        return true;
    } catch (err) {
        console.log('Something failed:', err)
        return false;
    }
}

// connectClient();

module.exports = {
    openFourWheelerEntryBoom,
    openFourWheelerExitBoom
 }
