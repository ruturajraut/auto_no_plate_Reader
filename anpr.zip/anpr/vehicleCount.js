var db = require("./database");

function getVehicleCounts(data){
    let carEntryCount = 0;
    let bikeEntryCount = 0;
    let carExitCount = 0;
    let bikeExitCount = 0;

    if(data.hasOwnProperty("Time")){
        //convert time to GMT+5:30
    }

    //parsing Line 1 - Entry Ramp cars
    if(data.hasOwnProperty('Line1') && data.Line1.length > 0 && data.Line1[0].hasOwnProperty('list')){
        // carEntryCount = data.Line1[0].list.reduce((total,arr)=>{
        //     console.log(arr);
        //     return total + parseInt(arr[1]);
        // })

        //car entry
        data.Line1[0].list.forEach(function(item){
            carEntryCount += item[1];
        })

        // car exit
        data.Line2[0].list.forEach(function(item){
            carExitCount += item[2];
        })

        //bike entry
        data.Line3[0].list.forEach(function(item){
            bikeEntryCount += item[1];
        })

        // bike exit
        data.Line4[0].list.forEach(function(item){
            bikeExitCount += item[2];
        })

    }
    console.log("cars in=" + carEntryCount);
    console.log("cars out=" + carExitCount);
    console.log("bikes in=" + bikeEntryCount);
    console.log("bikes out=" + bikeExitCount);

    db.createVehicleCountEntryLog({carEntryCount:carEntryCount,carExitCount:carExitCount,bikeEntryCount:bikeEntryCount,bikeExitCount:bikeExitCount});
}

module.exports = {
    getVehicleCounts
}