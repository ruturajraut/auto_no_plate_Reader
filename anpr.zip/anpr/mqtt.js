const mqtt=require('async-mqtt');
const gvl = require('./gvl');

let client = null;
const options = {
    clientId:"jana-anpr-server-mqtt-client",
    // host : gvl.mqtt_broker_details.server_url,
    port : gvl.mqtt_broker_details.port,
    username:gvl.mqtt_broker_details.user,
    password:gvl.mqtt_broker_details.pass,
    clean:true
};

async function connectClient(){
    // console.log(options);
    client  = await mqtt.connectAsync(gvl.mqtt_broker_details.server_url,options);
    // console.log("connected flag  "+client.connected);
    
}


function sendMsgForDisplay(displayId,vehicleNumber,whitelistApproved,ownerName,ownerUnit){
    sendData = {}
    sendData.vehicleNumber = vehicleNumber;
    sendData.whitelistApproved = whitelistApproved;

    if(whitelistApproved){
        sendData.ownerName = ownerName;
        sendData.ownerUnit = ownerUnit;
    }

    sendData = JSON.stringify(sendData);
    console.log(sendData)
    publishMessage("anpr-" + displayId,sendData);
}


async function publishMessage(topic,message){
    if(!client || !client.connected) await connectClient();

    console.log("is client connected=" + client.connected);

    try {
		await client.publish(topic, message);
		// This line doesn't run until the server responds to the publish
		// await client.end();
		// This line doesn't run until the client has disconnected without error
		// console.log("Done");
	} catch (e){
		// Do something about it!
		console.log(e.stack);
		// process.exit();
	}
}

module.exports = {
    sendMsgForDisplay
}