var express = require('express');
var db = require("./database");
const bodyParser = require("body-parser");
const plc = require('./plc');
const mqtt = require('./mqtt');
const synchronizeEntryLogs = require('./database').synchronizeEntryLogs;
const synchronizeLocalDataOnline = require('./database').synchronizeLocalDataOnline;
const checkCameraIdForFourWheeler = require('./database').checkCameraIdForFourWheeler;
// const vehicleCount = require('./vehicleCount');
var app = express();
const port = 2202;

// serve your css as static
app.use(express.static(__dirname));

// get our app to use body parser 
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json());

// Call the synchronization function when the server starts
// (async () => {
//   try {
//       // await db.synchronizeEntryLogs();
//       await db.syncData();
//   } catch (error) {
//       console.error('Error synchronizing entry logs:', error);
//   }
// })();

setInterval(async function () {
  try {
    // await db.synchronizeEntryLogs();
    console.log("sync function called");
    await db.syncData();
  } catch (error) {
    console.error('Error synchronizing entry logs:', error);
  }
}, 5000)

// (async () => {
//   try {
//       await db.synchronizeLocalDataOnline();
//       console.log(' Current vehicle data synchronized successfully.');
//   } catch (error) {
//       console.error('Error synchronizing current vehicle data:', error);
//   }
// })();

//checkCameraIdForFourWheeler();
// (async () => {
//   try {
//       await checkCameraIdForFourWheeler();
    
//       console.log('checkCameraIdForFourWheeler synchronized successfully.');
//   } catch (error) {
//       console.error('Error synchronizing checkCameraIdForFourWheeler:', error);
//   }
// })();


app.post("/new-plate-four-wheeler-entry", async (req, res) => {
  console.log('\n\n----------------');
  console.log(req.body);
  console.log(`@ ${new Date()}`);

  if(req.body.hasOwnProperty("plate") && req.body.plate){
    var vehicleImage = 0;
    const vehicleDetails = await db.checkWhiteList(req.body.plate);
    if(req.body.hasOwnProperty("plateimage")){vehicleImage = req.body.plateimage};

    if(vehicleDetails){ // if vehicle number was found in the whitelist
      await plc.openFourWheelerEntryBoom();
      //me
      console.log("Open Four Wheeler entry boom")
      db.createFourWheelerEntryLog(vehicleDetails,vehicleImage,true);
      // mqtt.sendMsgForDisplay(
      //   "jana-four-wheeler-entry",
      //   vehicleDetails.vehicle_number,
      //   true,
      //   vehicleDetails.owner_name,
      //   vehicleDetails.owner_unit
      // )
      
        
    }
    else{
      await plc.openFourWheelerEntryBoom();
      //me
      console.log("Open Four Wheeler entry boom")
      db.createFourWheelerEntryLog({id : 0,vehicle_number : req.body.plate},vehicleImage,true);
      
      // mqtt.sendMsgForDisplay(
      //   "quantum-four-wheeler-entry",
      //   req.body.plate,
      //   false
      // )
    }

    res.send(true);
  }
});

app.post("/new-plate-four-wheeler-exit", async (req, res) => {
  console.log('\n\n----------------');
  console.log(req.body);
  console.log(`@ ${new Date()}`);

  if(req.body.hasOwnProperty("plate") && req.body.plate){
  
    const vehicleDetails = await db.checkWhiteList(req.body.plate);
    if(req.body.hasOwnProperty("plateimage")){vehicleImage = req.body.plateimage};

    if(vehicleDetails){ // if vehicle number was found in the whitelist
      await plc.openFourWheelerExitBoom();
      //me
      console.log("Open Four Wheeler exit boom")
      db.createFourWheelerExitLog(vehicleDetails,vehicleImage,true);
      // mqtt.sendMsgForDisplay(
      //   "jana-four-wheeler-exit",
      //   vehicleDetails.vehicle_number,
      //   true,
      //   vehicleDetails.owner_name,
      //   vehicleDetails.owner_unit
      // )
    }
    else{
      await plc.openFourWheelerExitBoom();
      console.log("Open Four Wheeler exit boom")
      db.createFourWheelerExitLog({id : 0,vehicle_number : req.body.plate},vehicleImage,false);
      // mqtt.sendMsgForDisplay(
      //   "quantum-four-wheeler-exit",
      //   req.body.plate,
      //   false
      // )
    }

    res.send(true);
  }
});

app.post("/vehicleCount", async (req, res) => {
  console.log("recieving vehicle count data....")
  console.dir(req.body,{depth:4});
  console.log(`@ ${new Date()}`);
  vehicleCount.getVehicleCounts(req.body);
});

app.listen(port, () => {
    console.log(`NodeJS Server for listening to Panasonic ANPR Data. Running on port:${port}`);
    console.log(`Developed by : Claypot Technologies`);
    console.log('Author : Gautam Kulkarni')
  })


