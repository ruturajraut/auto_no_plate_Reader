controller_net_id="5.113.42.88.1.1"
controller_port = 851

mqtt_broker_details = {
    'server_url' : 'mqtt://fortuitous-optician.cloudmqtt.com',
    'user' : 'geopcxoy',
    'pass' : 'osn07Rx4Eu-C',
    'port' : 1883,
    // 'ssl_port' : 8883,
    'websockets_port' : 443
}

mysql_details = {
    mysqlHostName : "claypot-db-instance.ci3ywfy1btrn.ap-south-1.rds.amazonaws.com",
    mysqlPort : 3306,
    mysqlUser : "claypot_db_user",
    mysqlPassword : "claypot_db_user_password",
    mysqlDatabase : "jana_db",
    whitelistTable : "jana_numberplate_whitelist",
    entryLogTable : "jana_anpr_logs",
    currentVehiclesTable : "jana_current_vehicles"
}
mysql_details_local = {
    mysqlHostName : "localhost",
    mysqlPort : 3306,
    mysqlUser : "root",
    mysqlPassword : "claypot@123",
    mysqlDatabase : "jana_db",
    entryLogTable : "jana_anpr_logs_local",
    currentVehiclesTable : "jana_current_vehicles_local"
}

module.exports = {
    controller_net_id,
    controller_port,
    mqtt_broker_details,
    mysql_details,mysql_details_local
}
