// var mysql = require('mysql');
var mysql = require('mysql2');
var gvl = require('./gvl');
//const { query } = require('express');

const isOnline = import('is-online');



// var con = mysql.createConnection({
//     host: gvl.mysql_details.mysqlHostName,
//     port:gvl.mysql_details.mysqlPort,
//     user: gvl.mysql_details.mysqlUser,
//     password: gvl.mysql_details.mysqlPassword,
//     database: gvl.mysql_details.mysqlDatabase,
// });

const pool = mysql.createPool({
    host: gvl.mysql_details.mysqlHostName,
    port : gvl.mysql_details.mysqlPort,
    user: gvl.mysql_details.mysqlUser,
    password : gvl.mysql_details.mysqlPassword,
    database: gvl.mysql_details.mysqlDatabase,
    waitForConnections: true,
    connectionLimit: 10,
    maxIdle: 10, // max idle connections, the default value is the same as `connectionLimit`
    idleTimeout: 60000, // idle connections timeout, in milliseconds, the default value 60000
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0
});

const localPool = mysql.createPool({
    host:gvl.mysql_details_local.mysqlHostName,
    port:gvl.mysql_details_local.mysqlPort,
    user: gvl.mysql_details_local.mysqlUser,
    password : gvl.mysql_details_local.mysqlPassword,
    database: gvl.mysql_details_local.mysqlDatabase,
    waitForConnections: true,
    connectionLimit: 10,
    maxIdle: 10, // max idle connections, the default value is the same as `connectionLimit`
    idleTimeout: 60000, // idle connections timeout, in milliseconds, the default value 60000
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0,
    dateStrings: true

})




async function checkWhiteList(plate){
    
    plate = plate.toUpperCase();
    let query = `SELECT * FROM ${gvl.mysql_details.whitelistTable} where vehicle_number='${plate}'`;
    
    // console.log(query);

    try{
        const promisePool = pool.promise();
        
        // query database using promises
        const [rows,fields] = await promisePool.query(query);
        // console.log(rows);

        if(rows.length > 0){
            return rows[0];
        }
        else{
            return false;
        }
    }
    catch(e){
        //console.log(e.stack);
        //me
        return false;

    }
}

async function createFourWheelerEntryLog(vehicleDetails,vehicleImage,success){
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset*60*1000));
    splitArr = dt.toISOString().split('T');
    dtString = splitArr[0];
    tmString = splitArr[1];

    // console.log(vehicleDetails);

    try{
        
        const promisePool = pool.promise();
        let query = `INSERT INTO ${gvl.mysql_details.entryLogTable} (owner_id,vehicle_number, camera_id,success,date,time,img)`;
        query += `VALUES (?,?,?,?,?,?,?)`;
        console.log(query)

        const [rows,fields] = await promisePool.query(query,[vehicleDetails.id,vehicleDetails.vehicle_number,"4 Wheeler Entry Lane",success,dtString,tmString,vehicleImage]);
        console.log([rows,fields])
    }
    catch(e){
        //here
        console.log(" Before entry log local vehicle")
        createFourWheelerEntryLogLocal(vehicleDetails,vehicleImage,success)
        return;
        // synchronizeEntryLogs(vehicleDetails,success)
        //syncRecordOnline(vehicleDetails)
    
    }

    try{
        const promisePool = pool.promise();
        const lastFourDigits = vehicleDetails.vehicle_number.substr(vehicleDetails.vehicle_number.length - 4);
        console.log("last four digits=" + lastFourDigits);
        const middleFourDigits = vehicleDetails.vehicle_number.substring(4, 8);


        let query = `select * from ${gvl.mysql_details.currentVehiclesTable} where vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        console.log(query);
        const [rows,fields] = await promisePool.query(query);
        console.log("rows=");
        console.log(rows.length);

        if(rows.length > 0){
            console.log(`vehicle number ${lastFourDigits} already exists in current vehicles table`);
            return;
        }
        else{
            console.log(`vehicle number ${lastFourDigits} does not exists in current vehicles table`);
        }

        query = `INSERT INTO ${gvl.mysql_details.currentVehiclesTable} (vehicle_number,entry_dt,entry_tm,entry_dttm,in_premise)`;
        query += ` VALUES (?,?,?,?,?)`;
        console.log(query);
        [insert_rows,insert_fields] = await promisePool.query(query,[vehicleDetails.vehicle_number,dtString,tmString,dtString + " " + tmString,true]);
    }
    catch(e){   //if offline
        console.log(e.stack);
        
        
    }

}

//copy fn
async function createFourWheelerEntryLogLocal(vehicleDetails,vehicleImage,success){
    console.log("----&&")
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset*60*1000));
    splitArr = dt.toISOString().split('T');
    dtString = splitArr[0];
    tmString = splitArr[1].split('.')[0];

    console.log(vehicleDetails);

    try{
        const promisePool = localPool.promise();
        console.log(promisePool)
        let query = `INSERT INTO ${gvl.mysql_details_local.entryLogTable} (owner_id,vehicle_number,camera_id,success,date,time,img)`;
        query += ` VALUES (?,?,?,?,?,?,?)`;
        console.log(query)
        const [rows,fields] = await promisePool.query(query,[vehicleDetails.id,vehicleDetails.vehicle_number,"4 Wheeler Entry Lane",success,dtString,tmString,vehicleImage]);
    }
    catch(e){
        console.log(e.stack);
    }


}
//--------------------------------------------




async function createFourWheelerExitLog(vehicleDetails,vehicleImage,success){
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset*60*1000));
    splitArr = dt.toISOString().split('T');
    dtString = splitArr[0];
    tmString = splitArr[1];
    dttmString=dtString + " " + tmString;

    // console.log("----&&")   create vehicl exit log local
    // let dt = new Date();
    // const offset = dt.getTimezoneOffset();
    // dt = new Date(dt.getTime() - (offset*60*1000));
    // splitArr = dt.toISOString().split('T');
    // dtString = splitArr[0];
    // tmString = splitArr[1].split('.')[0];
    
    // console.log(vehicleDetails);

    try{
        const promisePool = pool.promise();
        let query = `INSERT INTO ${gvl.mysql_details.entryLogTable} (owner_id,vehicle_number, camera_id,success,date,time,img)`;
        query += ` VALUES (?,?,?,?,?,?,?)`;
        const [rows,fields] = await promisePool.query(query,[vehicleDetails.id,vehicleDetails.vehicle_number,"4 Wheeler Exit Lane",success,dtString,tmString,vehicleImage]);

        //syncEntryLogWithOnlineTable();
    }
    catch(e){
        //here
        console.log(" Before exit log local vehicle")
        createFourWheelerExitLogLocal(vehicleDetails,vehicleImage,success);
        
        
        
        return;
    }

    try{
        const promisePool = pool.promise();
        const lastFourDigits = vehicleDetails.vehicle_number.substr(vehicleDetails.vehicle_number.length - 4);
        const middleFourDigits = vehicleDetails.vehicle_number.substring(4, 8);
        // query = `DELETE FROM ${gvl.mysql_details.currentVehiclesTable} WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        //let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise=0,exit_dt='${dtString}',exit_tm='${tmString}',exit_dttm='${dttmString}' WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        //await promisePool.query(query);

        let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise=0,exit_dt='${dtString}',exit_tm='${tmString}',exit_dttm='${dttmString}' WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        console.log(query)
        const [rows,fields]=await promisePool.query(query);

        //let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise = 0, exit_dt = ?, exit_tm = ?, exit_dttm = ? WHERE vehicle_number = ? LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        //await promisePool.query(query, [dtString, tmString, dttmString, vehicleDetails.vehicle_number]);


    }
    catch(e){
        console.log(e.stack);

    }

}

// copy fn of exit
async function createFourWheelerExitLogLocal(vehicleDetails,vehicleImage,success){
    let dt = new Date();
    const offset = dt.getTimezoneOffset();
    dt = new Date(dt.getTime() - (offset*60*1000));
    splitArr = dt.toISOString().split('T');
    dtString = splitArr[0];
    tmString = splitArr[1].split('.')[0];
    dttmString=dtString + " " + tmString;
    
    // console.log(vehicleDetails);

    try{
        const promisePool = localPool.promise();
        console.log(promisePool)
        let query = `INSERT INTO ${gvl.mysql_details_local.entryLogTable} (owner_id,vehicle_number, camera_id,success,date,time,img)`;
        query += ` VALUES (?,?,?,?,?,?,?)`;
        const [rows,fields] = await promisePool.query(query,[vehicleDetails.id,vehicleDetails.vehicle_number,"4 Wheeler Exit Lane",success,dtString,tmString,vehicleImage]);

        
    }
    catch(e){
        console.log(e.stack);
    }

    

}


//------------------------------
//sync function
//-----------------------------
async function syncData(){
    console.log("sync function called");
    const localLogs = await fetchLocalLogs();
    // console.log(localEntryLogs);
    for(const vehicleLog of localLogs) {
        // console.log(entryLog);
        // console.log("------------");
        const syncLogsSuccessful = syncLogsOnline(vehicleLog);
        const syncCurrentSuccessful = syncCurrentTable(vehicleLog);

        
        
        
        // if(syncLogsSuccessful && syncCurrentSuccessful){
        //     removeRecordFromLocalTable(vehicleLog)
        // }
    }
}



// Function to fetch entry logs from the local entry log table
async function fetchLocalLogs() {
    // Implement logic to fetch entry logs from the local entry log table
    try {
        // Create a connection pool for the local database
        const promisePool = localPool.promise();
        // Fetch entry logs from the local entry log table
        const query = "SELECT * FROM jana_anpr_logs_local"; // Modify query according to your table structure
        const [rows, fields] = await promisePool.query(query);

        // Return the fetched entry logs
        console.log(rows);
        return rows;
        
    } catch (error) {
        console.error("Error occurred while fetching local entry logs:", error);
        return []; // Return an empty array in case of error
    }

}


// Function to synchronize a local entry log with the online entry log table
async function syncLogsOnline(entryLog) {
    try {
        console.log("Entrylog",entryLog)
        // Attempt to insert the entry log into the online entry log table
        const promisePool = pool.promise();
        //console.log(promisePool)
        let query = 'INSERT INTO jana_anpr_logs_test (owner_id, vehicle_number, camera_id, success, date, time,img)'
        query += ` VALUES (?,?,?,?,?,?,?)`;
        const [rows, fields] = await promisePool.query(query,[
            entryLog.owner_id,
            entryLog.vehicle_number,
            entryLog.camera_id,
            entryLog.success,
            entryLog.date,
            entryLog.time,
            entryLog.img
        ])
        syncCurrentTable(entryLog) 
        
        // If insertion is successful, update the exit_dt and exit_tm in the current_vehicle_test table
        //await updateExitDateTime(entryLog.vehicle_number, exitDt, exitTm);

        // If insertion is successful, remove the entry log from the local entry log table
        //await removeLocalEntryLog(entryLog.id);
    } catch (error) {
        // console.error("Error occurred while synchronizing entry log with online table:", error);
        console.log("not able to sync online...probably no internet")
        
    }    
}



//this function syncs local log record with online current table
async function syncCurrentTable(x) {
    try {

        const camera_id = x.camera_id;
        const dttm = x.date + " " + x.time;
        // Create a connection pool for the online database
        const promisePool = pool.promise();
        //console.log("hello ")
        //console.log(promisePool)
          // Check if the record is an entry or an exit
          if (camera_id === "4 Wheeler Entry Lane") {

            // Prepare the SQL query to insert an entry record into the current vehicle table
            const query = "INSERT INTO jana_current_vehicles_test (vehicle_number,entry_dt,entry_tm,entry_dttm,in_premise) VALUES (?,?, ?, ?, ?)";

            const [rows,fields] = await promisePool.query(query,[x.vehicle_number,x.date,x.time,dttm,true]);

            console.log("Entry record synchronized successfully:");
            removeRecordFromLocalTable(x)

        }
        else if (camera_id === "4 Wheeler Exit Lane") {
            

            const lastFourDigits = x.vehicle_number.substr(x.vehicle_number.length - 4);
            const middleFourDigits = x.vehicle_number.substring(4, 8);
            //     // Prepare the SQL query to update an exit record in the current vehicle table
                
            let query = `UPDATE jana_current_vehicles_test SET in_premise=0,exit_dt='${x.date}',exit_tm='${x.time}',exit_dttm='${dttm}' WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
            console.log(query)
            const [rows,fields]=await promisePool.query(query);

            removeRecordFromLocalTable(x)

        } else {
            console.error("Invalid action:");
            
        }



        // Once synchronized, you may want to remove the record from the local log table
        //await removeRecordFromLocalTable(record.id); // Adjust this function according to your implementation
    } catch (error) {
        // console.error("Error occurred while synchronizing record online:", error);
        console.log("Not able to sync current table...probably no internet");
    }
}


async function removeRecordFromLocalTable(x) {
    try {
        const promisePool = localPool.promise();
        const query = "DELETE FROM jana_anpr_logs_local WHERE id = ?";
        await promisePool.query(query, [x.id]);
        console.log("Record removed from local table:", x.id);
    } catch (error) {
        console.error("Error occurred while removing record from local table:", error);
    }
}








// Function to check the camera_id for four-wheeler exits and entries in the local entry log table
async function checkCameraIdForFourWheeler(entryLog) {
    try {
        // if (!entryLog2 || !entryLog2.camera_id) {
        //     throw new Error("Entry log is missing or does not contain camera_id");
        // }
        // Create a connection pool for the local database
        const promisePool = localPool.promise();

        // Prepare the SQL query to check the camera_id for the provided vehicle number
        let query = "SELECT * FROM jana_anpr_logs_local WHERE camera_id = ?";

        const [rows, fields] = await promisePool.query(query,[
            entryLog.camera_id
            //camera_id
           
        ]);
        console.log(promisePool)


        // Execute the query with the vehicle number as the parameter
        //const [rows, fields] = await promisePool.localPool.query(query, [vehicle_number]);

        // If count is greater than 0, it means there was an exit for the vehicle
        if (rows.length > 0 ) {
        const promisePool = pool.promise();
        // query = `DELETE FROM ${gvl.mysql_details.currentVehiclesTable} WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise=0,exit_dt='${dtString}',exit_tm='${tmString}',exit_dttm='${dttmString}'`;
        await promisePool.query(query);

        return 0; // Four-wheeler exit

        } else {
        const promisePool = pool.promise();
        // query = `DELETE FROM ${gvl.mysql_details.currentVehiclesTable} WHERE vehicle_number LIKE '%${lastFourDigits}%' or vehicle_number LIKE '%${middleFourDigits}%'`;
        let query = `UPDATE ${gvl.mysql_details.currentVehiclesTable} SET in_premise=1,exit_dt='${dtString}',exit_tm='${tmString}',exit_dttm='${dttmString}'`;
        await promisePool.query(query);
        
        return 1; // Four-wheeler entry

        }
    } catch (error) {
        console.error("Error occurred while checking camera_id for four-wheeler exits and entries:", error);
        return -1; // Return -1 to indicate an error occurred
    }
}



// Schedule periodic synchronization of local entry logs with the online entry log table
// setInterval(synchronizeEntryLogs, /* Specify synchronization interval in milliseconds */3000);




module.exports = {
    checkWhiteList,
    createFourWheelerEntryLog,
    createFourWheelerExitLog,
    syncData
   // checkCameraIdForFourWheeler: checkCameraIdForFourWheeler
}